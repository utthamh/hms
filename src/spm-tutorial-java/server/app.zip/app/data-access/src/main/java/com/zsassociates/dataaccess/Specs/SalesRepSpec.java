package com.zsassociates.dataaccess.Specs;

import com.zsassociates.dataaccess.util.Specs;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

public class SalesRepSpec extends Specs.BaseSpec {
    @NoArgsConstructor
    public static class GetAllSalesRep extends Specs.BaseSpec {
    }
}
