# ZSUI Forms #
Form elements and input controls like Text fields, Inputs, Buttons, Selects, Date picker, Tags, Filters, Checkboxes, Color inputs, ...

## INSTALL ##
npm install

## Build ##
npm run build

## Development: watch changes ##
npm start

## TEST ##
After build open in browser test/index.html

## Documentation##
After build open in browser docs/index.html

## Demo examples ##
After build open in browser dist/*