# ZSUI Dialog #

ZSUI Dialog v3.0.0

## INSTALL ##
npm install

## Build ##
npm run build

## Development: watch changes ##
npm start

## TEST ##
open in browser test/index.html

## Documentation ##
open in docs/index.html