## Usage Syntax

```console
node.exe upload-folder <src-folder-path> <dest-folder-path>
```
## Example

```console
node upload-folder dist stage
```
will copy `dist` folder on your local to `stage` folder on your S3 bucket.