package com.zsassociates.services;

import com.zsassociates.dataaccess.Dao.SalesRepDao;
import com.zsassociates.models.SalesRep;

import javax.inject.Inject;
import java.util.List;

public class SalesRepService implements SalesRepDaoService {

    private SalesRepDao salesRepDao;

    @Inject
    public SalesRepService(SalesRepDao salesRepDao) {
        this.salesRepDao = salesRepDao;
    }

    @Override
    public List<SalesRep> getAllSalesRep() {
      return this.salesRepDao.getAll();
    }

    @Override
    public SalesRep save(SalesRep s) {
        long id=this.salesRepDao.create(s);
        s.Id=id;
        return s;
    }

    @Override
    public SalesRep update(SalesRep s, Integer id) {
        this.salesRepDao.update(s);
       // s.Id=id;
        return s;
    }

    @Override
    public Integer delete(Long id) {
        //SalesRep s=this.salesRepDao.getById(id);
      //  this.salesRepDao.delete(s);
        return 1;
    }

    @Override
    public SalesRep getById(Long id) {
        return null;
        //return this.salesRepDao.getById(id);
    }
}
