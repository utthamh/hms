# ZSUI authentication module #
ZSUI Authentication v3.1.0

## INSTALL ##
npm install

## Build ##
npm run build

## Development: watch changes ##
npm start

## TEST ##
After build open in browser test/index.html

## Documentation##
After build open in browser docs/index.html

## Demo examples ##
After build open in browser dist/*